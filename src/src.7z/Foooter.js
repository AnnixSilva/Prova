import React from "react";
import "./Foooter.css";

function Foooter() {
    return (
        <footer>
            <p className="textinho-footer">&copy; @ 2024 Todos od direitos reservados ao povo do 3º/Informática para internet.</p>
            <p className="textinho-footer">&copy; Contato: almossar@cabacos.com</p>
        </footer>
    );
}

export default Foooter;